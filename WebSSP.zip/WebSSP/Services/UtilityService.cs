﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Onlife.Automation.UiTesting.WebSSP.Services
{
    public class UtilityService
    {
        public string DateDiff(DateTime _startDate, DateTime _endDate)
        {
            string _dateDiff = DateDiff(new DateTimeOffset(_startDate), new DateTimeOffset(_endDate));
            return _dateDiff;
        }

        public string DateDiff(DateTimeOffset _startDate, DateTimeOffset _endDate)
        {
            string str = "";
            TimeSpan span = _endDate.Subtract(_startDate);
            if (span.TotalSeconds < 60)
                str = span.Seconds + " seconds";
            else if (span.TotalMinutes < 60)
            {
                if (span.TotalMinutes < 2)
                    str = span.Minutes + " minute";

                str = span.Minutes + " minutes";
            }
            else if (span.TotalHours < 24)
            {
                if (span.TotalHours < 2)
                    str = span.Hours + " hour";
                else
                    str = span.Hours + " hours";
            }
            else if (span.Days < 30)
            {
                if (span.TotalDays < 2)
                    str = span.Days + " day";
                else
                    str = span.Days + " days";
            }
            else if (span.TotalDays > 30)
            {
                if ((span.TotalDays / 30) < 2)
                    str = (span.TotalDays / 30) + " month";
                else
                    str = span.TotalDays / 30 + " months";
            }
            return str;

        }
    }
}
