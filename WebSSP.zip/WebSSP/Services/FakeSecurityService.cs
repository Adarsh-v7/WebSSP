﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Onlife.Automation.UiTesting.WebSSP.Models;
using Onlife.Automation.UiTesting.WebSSP.Interfaces;

namespace Onlife.Automation.UiTesting.WebSSP.Services
{
    public class FakeSecurityService:IFakeSecurityService
    {
        public User LoginCheck(string username, string password)
        {
            var ret = new User();

            username = username.Trim().ToLower();

            if (password.Equals("password11"))
            {
                var random = new Random();
                ret.UserId = random.Next(1000, 9999);
                ret.Password = password;
                ret.UserName = username;

                if (username.Contains("_"))
                {
                    var fn = username.Substring(0, username.IndexOf("_", 0));

                    ret.FirstName = fn[0].ToString().ToUpper() + fn.Substring(1);

                    var ln = username.Substring((username.IndexOf("_", 0) + 1));

                    ret.LastName = ln[0].ToString().ToUpper() + ln.Substring(1);
                }
                else
                {
                    ret.FirstName = "SirOrMadam";
                    ret.LastName = username;
                }
            }

            return ret;
        }
    }
}
