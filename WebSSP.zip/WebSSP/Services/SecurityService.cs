﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Onlife.Automation.UiTesting.WebSSP.Models;
using Onlife.Automation.UiTesting.WebSSP.Interfaces;
using Microsoft.Extensions.Configuration;
using System.Web;
using System.Net.Http;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using Newtonsoft.Json;
using Microsoft.IdentityModel.Tokens;

namespace Onlife.Automation.UiTesting.WebSSP.Services
{
    public class SecurityService : ISecurityService
    {
        public IConfiguration Configuration { get; }
        public SecurityService(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public async Task<string> ValidateUser(string username, string password)
        {
            JwtSecurityToken JwtToken = new JwtSecurityToken();
            string strToken = "";
            string encodedPassword = HttpUtility.UrlEncode(password);
            var body = "username=" + username + "&password=" + password + "&grant_type=password";

            StringContent content = new StringContent(body, Encoding.UTF8, "application/json");
            string url = Configuration["Jwt:AUTHENTICATION_URL"] + "oauth/token";
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.PostAsync(url, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    if (response.IsSuccessStatusCode)
                    {
                        TokenPara stream = JsonConvert.DeserializeObject<TokenPara>(apiResponse);
                        var handler = new JwtSecurityTokenHandler();
                        JwtToken = handler.ReadJwtToken(stream.access_token);
                        strToken=stream.access_token;
                    }
                }
            }
            return strToken;
        }

        public async Task<bool> IsValidToken(string key, string issuer, string token)
        {
            var mySecret = Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]);
            var mySecurityKey = new SymmetricSecurityKey(mySecret);

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidIssuer = Configuration["Jwt:Issuer"],
                    ValidAudience = Configuration["Jwt:Audience"],
                    IssuerSigningKey = mySecurityKey,
                }, out SecurityToken validatedToken);

            }
            catch(Exception ex)
            {
                return false;
            }
            return true;
        }

        
    }
}

class TokenPara
{
    public string access_token { get; set; }
    public string token_type { get; set; }
    public int expires_in { get; set; }

}
