using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting.Logging;
using NLog;
using NLog.Extensions.Logging;
using NLog.Web;

namespace Onlife.Automation.UiTesting.WebSSP
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var config = new ConfigurationBuilder()
               .SetBasePath(System.IO.Directory.GetCurrentDirectory())
               .AddJsonFile("nlogsettings.json", optional: false, reloadOnChange: true)
               .Build(); 

            var cfg = new NLogLoggingConfiguration(config.GetSection("NLog"));

            var logger = NLogBuilder.ConfigureNLog(cfg).GetCurrentClassLogger();

            try
            {
                CreateHostBuilder(args).Build().Run();
            }
            catch (Exception exception)
            {
                logger.Error(exception, "Stopped program because of exception");
                throw;
            }
            finally
            {
                logger.Info("Exiting host builder");
                NLog.LogManager.Shutdown();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureLogging((hostingContext,logging) =>
                {
                    logging.ClearProviders();
                    logging.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Trace);
                    logging.AddDebug();
                    logging.AddNLog(hostingContext.Configuration.GetSection("NLog"));
                })
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.ConfigureKestrel(serveropts => {
                        serveropts.Limits.MaxConcurrentConnections = 100;
                        serveropts.Limits.MaxConcurrentUpgradedConnections = 100;
                        serveropts.Limits.KeepAliveTimeout = TimeSpan.FromMinutes(10);
                        serveropts.Limits.RequestHeadersTimeout = TimeSpan.FromMinutes(10);
                        //todo: learn about kestrel settings and options, how to get from appsettings.json file, 
                        // and implmement which ones we need using the config values
                    })
                    .UseStartup<Startup>();
                })
                .UseNLog();
    }
}
