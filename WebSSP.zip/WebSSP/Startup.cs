using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog.Web;
using Onlife.Automation.UiTesting.InfoServices;
using Onlife.Automation.UiTesting.InfoServices.Config;
using Onlife.Automation.UiTesting.Objects.Configs;
using Onlife.Automation.UiTesting.Requests;
using Onlife.Automation.UiTesting.Results;


namespace Onlife.Automation.UiTesting.WebSSP
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
            services.AddDistributedMemoryCache();
            services.AddSession(options =>
            {
                options.Cookie.Name = ".UiTestingWebSSP.Session";
                options.Cookie.IsEssential = true;
            });
            services.AddHttpContextAccessor();

            services.Configure<SspConfig>(options => Configuration.GetSection("SspConfig").Bind(options));
            services.AddControllersWithViews();
            services.AddControllers();

            services.Configure<UiTestingConfig>(options => Configuration.GetSection("UiTestingConfig").Bind(options));
            services.AddRequestsServiceIoc();
            services.AddResultsServiceIoc();

            services.Configure<InfoServicesConfig>(options => Configuration.GetSection("InfoServicesConfig").Bind(options));
            services.AddInfoServicesIoc();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                /* todo: need to research better error handling
                 *  need to see how to handle the apis being in a web project
                 *  
                 *  references: 
                 *          https://stackoverflow.com/questions/38630076/asp-net-core-web-api-exception-handling
                 *          https://www.devtrends.co.uk/blog/handling-errors-in-asp.net-core-web-api
                 *          https://docs.microsoft.com/en-us/aspnet/core/web-api/handle-errors?view=aspnetcore-5.0
                 *  
                 * 
                 */

                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();
            app.UseSession();

            app.UseCookiePolicy();
            app.UseSession();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "AppTest",
                    pattern: "{controller=User}/{action=Login}/{id?}");

                endpoints.MapControllers();
            });

            app.ApplicationServices.SetupNLogServiceLocator();

            //loggerFactory.AddNLog();
        }
    }
}
