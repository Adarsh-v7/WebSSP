﻿using Onlife.Automation.UiTesting.Objects.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Onlife.Automation.UiTesting.WebSSP.Models
{
    public class ResultsFilter
    {
        public int? AppId { get; set; }
        public string EnvironmentName { get; set; }
        //public string Category { get; set; } // finished or Queue.
        // public bool AllUser { get; set; } // for All users.
        public List<Result_TestParameter> Parameters { get; set; }
        public int CaseCount { get; set; }
        public int CasesFailed { get; set; }
        public DateTimeOffset TestStartTime { get; set; }
        public DateTimeOffset TestEndTime { get; set; }
        public string TestTypeName { get; set; }
    }
}
