﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Onlife.Automation.UiTesting.Objects;
using Onlife.Automation.UiTesting.Objects.AppObjects;
using Onlife.Automation.UiTesting.Objects.Enums;
using Onlife.Automation.UiTesting.Objects.Info;

namespace Onlife.Automation.UiTesting.WebSSP.Models
{
    public class RunNewTest
    {
        public IEnumerable<App> AppInfoList { get; set; }
        public string TestToken { get; set; }
        public Guid GroupGuid { get; set; }
        public List<AppEnvironment> TargetEnvironments { get; set; }
        public List<AppTestType> TestTypes { get; set; }
        public Objects.Browser Browser { get; set; }
        public OsResolution Resolution { get; set; }
        public IEnumerable<Objects.OperatingSystem> Os { get; set; }
        public List<MobileAppBranch> Branches { get; set; }
        
    }
}
