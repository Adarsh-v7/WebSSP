﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Onlife.Automation.UiTesting.InfoServices.Config;
using Onlife.Automation.UiTesting.InfoServices.Interfaces;
using Onlife.Automation.UiTesting.Objects;
using Onlife.Automation.UiTesting.Objects.AppObjects;
using Onlife.Automation.UiTesting.Objects.GroupObjects;
using Onlife.Automation.UiTesting.Objects.Requests;
using Onlife.Automation.UiTesting.Objects.Results;
using Onlife.Automation.UiTesting.Requests.Objects;
using Onlife.Automation.UiTesting.WebSSP.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Onlife.Automation.UiTesting.WebSSP.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly SspConfig _config;
        private readonly IAppInfoService _appInfoService;
        private readonly IGroupInfoService _groupInfoService;
        private readonly IHostingEnvironment _hostingEnvironment;

        public HomeController(ILogger<HomeController> logger, IOptions<SspConfig> config, IAppInfoService appInfoService, IGroupInfoService groupInfoService, IHostingEnvironment hostingEnvironment)
        {
            _logger = logger;
            _config = config.Value;
            _appInfoService = appInfoService;
            _groupInfoService = groupInfoService;
            _hostingEnvironment = hostingEnvironment;
            //_baseURL= this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;

           
        }
        
        [Route("Home/")]
        [HttpGet]
        
        public async Task<IActionResult> Index()
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    string APIUrl = "api/results/summary?qt=10&page=1";
                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    List<Result_Summary> result_Summary = new List<Result_Summary>();
                    List<Batch_Summary> batch_Summary = new List<Batch_Summary>();
                    using (var response = await httpClient.GetAsync(_baseURL + APIUrl))
                    {
                        response.EnsureSuccessStatusCode();
                        IEnumerable<App> _appList = _appInfoService.GetAppInfoList();
                        result_Summary = await response.Content.ReadAsAsync<List<Result_Summary>>();
                    }

                    APIUrl = "api/results/batch/summary?page=1&qt=10&appid=3";
                    using (var response = await httpClient.GetAsync(_baseURL + APIUrl))
                    {
                        response.EnsureSuccessStatusCode();
                        IEnumerable<App> _appList = _appInfoService.GetAppInfoList();
                        batch_Summary = await response.Content.ReadAsAsync<List<Batch_Summary>>();
                    }

                   

                    return View(Tuple.Create(result_Summary, batch_Summary));
                }
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }
        }

        [Route("Home/Results")]
        [HttpGet]
        public async Task<IActionResult> ResultSummary(int? pageNum = 0, bool? by = false, int? appId = 0)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    string APIUrl = "api/results/summary?page=" + pageNum + "";
                    if (by == true)
                    {
                        APIUrl += "&by=" + TempData.Peek("User_FullName");

                        ViewBag.ShowMyResults = "1";
                    }
                    else
                    {
                        ViewBag.ShowMyResults = "";
                    }

                    if (appId != 0)
                    {
                        APIUrl += "&app=" + appId + "";
                    }

                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    using (var response = await httpClient.GetAsync(_baseURL + APIUrl))
                    {

                        response.EnsureSuccessStatusCode();
                        int Id = 3; //static appId 
                        List<Result_Summary> result_Summary = await response.Content.ReadAsAsync<List<Result_Summary>>();
                        foreach (var item in result_Summary)
                        {

                            item.Os = _appInfoService.GetOsInfoList();
                            IEnumerable<App> _appList = _appInfoService.GetAppInfoList();
                            List<App> SelectedApp = _appList.Where(x => x.AppId == Convert.ToInt32(Id)).ToList<App>();
                            item.TargetEnvironments = SelectedApp.Select(x => x.Environments).ToList()[0];
                            TempData["Os"] = JsonConvert.SerializeObject(item.Os);

                        }

                        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                        {
                            return PartialView("_ListSummary", result_Summary);
                        }

                        else
                        {
                            return View(result_Summary);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }

        }

        [Route("Home/ScheduleNewTest/{Id}")]
        public IActionResult ScheduleNewTest(int Id)
        {
            try
            {
                if (Id > 0)
                {
                    RunNewTest runNewTest = new RunNewTest();
                    IEnumerable<App> _appList = _appInfoService.GetAppInfoList();

                    var Os = _appInfoService.GetOsInfoList();
                    if (Id == 2)
                    {
                        runNewTest.Os = Os.Where(x => x.IsMobile == true && x.OsName == "Android").ToList<Objects.OperatingSystem>();
                    }
                    else
                        runNewTest.Os = Os;

                    runNewTest.AppInfoList = _appList;
                    TempData["AppId"] = Id;
                    

                    List<App> SelectedApp = _appList.Where(x => x.AppId == Convert.ToInt32(Id)).ToList<App>();
                    runNewTest.Branches = SelectedApp.Select(x => x.Branches).ToList()[0];
                    ViewBag.SelectedApp = SelectedApp;
                    runNewTest.TargetEnvironments = SelectedApp.Select(x => x.Environments).ToList()[0];
                    TempData["SelctedEnvironments"] = JsonConvert.SerializeObject(runNewTest.TargetEnvironments);
                    TempData["Os"] = JsonConvert.SerializeObject(runNewTest.Os);
                    //TempData["SelectedApp"] = JsonConvert.SerializeObject(SelectedApp);
                    return View(runNewTest);
                }
                else
                {
                    return RedirectToAction("Error");
                }
            }
            catch(Exception e)
            {
                _logger.LogError(e, $"HomeController ScheduleNewTest had an enhandled exception.");
                return RedirectToAction("Error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> ScheduleNewTest(TestRequestArgs args)
        {
            //args.TestToken = "69EAF8E4-F97C-426B-9274-A98FEB21C65E";
            var jsonStr = System.Text.Json.JsonSerializer.Serialize(args);

            try
            {
                using (var httpClient = new HttpClient())
                {
                    httpClient.Timeout = TimeSpan.FromMinutes(_config.PortalTestTimeout);
                    StringContent content = new StringContent(jsonStr, Encoding.UTF8, "application/json");

                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    using (var response = await httpClient.PostAsync(_baseURL + "api/portaltest", content))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        if (response.IsSuccessStatusCode)
                        {
                            return RedirectToAction("TestResults/" + apiResponse);
                            //ViewBag.Result = "<span class='text-success'>" + apiResponse + "</span>";
                        }
                        else
                        {
                            ViewBag.Result = "<span class='text-danger'>" + response.StatusCode + "/n API Message : " + apiResponse + "</span>";
                            return View();
                        }
                    }
                }
            }
            catch(Exception e)
            {
                _logger.LogError(e, $"HomeController HttpPost ScheduleNewTest had an enhandled exception.");
                return RedirectToAction("Error");
            }
            
        }
        
        [HttpPost]
        public async Task<JsonResult> SearchGroup(string _prefix, int _environmentId)
        {
            List<GroupSearchInfo> _listGroup = new List<GroupSearchInfo>();
            if (TempData.Peek("SelctedEnvironments") != null)
            {
                try
                {
                    List<AppEnvironment> appEnvironments = JsonConvert.DeserializeObject<List<AppEnvironment>>(TempData.Peek("SelctedEnvironments").ToString());
                    AppEnvironment selectedEnvironment = appEnvironments.Where(x => x.AppEnvironmentId == _environmentId).ToList()[0];
                    _groupInfoService.SetEnvironment(selectedEnvironment);
                    _listGroup = await _groupInfoService.GroupSearch(_prefix, 10);
                }
                catch(Exception e)
                {
                    _logger.LogError(e, $"HomeController HttpPost SearchGroup had an enhandled exception.");
                }
            }
            
            return Json(_listGroup);
        }


        public IActionResult Logout()
        {
            TempData.Remove("UserId");
            return RedirectToAction("Login", "User");
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [Route("Results/{Id}")]
        public async Task<IActionResult> TestResults(string Id)
        {
            try
            {
                //string path = System.IO.Path.Combine("Temp", "NewResult.json");
                //TestResult _result = JsonConvert.DeserializeObject<TestResult>(System.IO.File.ReadAllText(path));
                //return View(_result);
                using (var httpClient = new HttpClient())
                {
                    Guid requestGuid;
                    if (!Guid.TryParse(Id, out requestGuid))
                    {
                        _logger.LogError("RequestGuid");
                    }
                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    using (var response = await httpClient.GetAsync(_baseURL + "api/requests/" + requestGuid))
                    {
                        response.EnsureSuccessStatusCode();
                        TestResult resp = await response.Content.ReadAsAsync<TestResult>();
                        string str = JsonConvert.SerializeObject(resp);
                        if (resp.TestRequestId != 0)
                            return View(resp);
                        else
                            return RedirectToAction("Error");
                    }
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"HomeController Results ID Route had an enhandled exception.");
                return RedirectToAction("Error");
            }
        }

        [HttpGet]
        public async Task<JsonResult> GetTestBatchSize()
        {
            //List<BatchSize> _listBatchGroup = new List<BatchSize>();
           
                try
                {
                using (var httpClient = new HttpClient())
                {
                   
                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    using (var response = await httpClient.GetAsync(_baseURL + "api/requests/GetTestBatchSize"))
                    {
                        response.EnsureSuccessStatusCode();
                        List<BatchSize> result = await response.Content.ReadAsAsync<List<BatchSize>>();
                       // string str = JsonConvert.SerializeObject(result);
                        return Json(result);
                    }
                }
                }
                catch (Exception e)
                {
                    _logger.LogError(e, $"HomeController HttpPost GetTestBatchSize had an enhandled exception.");
                }
            

            return Json(null);
        }

        [HttpGet]
        public async Task<JsonResult> GetBatchSearchGroup(string _searchKey)
        {
            //List<BatchSize> _listBatchGroup = new List<BatchSize>();

            try
            {
                using (var httpClient = new HttpClient())
                {

                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    using (var response = await httpClient.GetAsync(_baseURL + "api/requests/GetBatchSearchGroup/" + _searchKey))
                    {
                        response.EnsureSuccessStatusCode();
                        List<BatchSize> result = await response.Content.ReadAsAsync<List<BatchSize>>();
                        // string str = JsonConvert.SerializeObject(result);
                        return Json(result);
                    }
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"HomeController HttpPost GetTestBatchSize had an enhandled exception.");
            }


            return Json(null);
        }

        [HttpPost]
        public async Task<JsonResult> SaveTestBatchRequest([FromBody]TestBatchRequestArgs args)
        {
           
            try
            {
                args.ScheduledDateTime = DateTime.Now.AddMinutes(1);
                var fieldCheck = args.ValidateRequiredFields();

                if (fieldCheck.Item1 == false)
                {
                    _logger.LogError($"Onlife.Automation.UiTesting.Requests.Data.DataProvider.SaveTestBatchRequestAsync failed argument validation with the following message: {fieldCheck.Item2}");
                    return Json(@"{""error message"": " + fieldCheck.Item2 + "}");
                }

                var jsonStr = System.Text.Json.JsonSerializer.Serialize(args);
              using (var httpClient = new HttpClient())
                {
                    
                    httpClient.Timeout = TimeSpan.FromMinutes(_config.PortalTestTimeout);
                    StringContent content = new StringContent(jsonStr, Encoding.UTF8, "application/json");

                    string _baseURL;
                    if (Request.IsHttps & (Request.Scheme == "http"))
                    {
                        _baseURL = this.Request.Scheme + "s://" + this.Request.Host + "/" + this.Request.PathBase;
                    }
                    else
                    {
                        _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    }
                    _logger.LogInformation($"Save Test Batch Request baseURL {_baseURL}"); //todo: remove after batch debugging is finished
                    using (var response = await httpClient.PostAsync(_baseURL + "api/testbatch/SaveTestBatchRequest", content))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        if (response.IsSuccessStatusCode)
                        {
                            return Json(apiResponse);
                        }
                        else
                        {
                            ViewBag.Result = "<span class='text-danger'>" + response.StatusCode + "/n API Message : " + apiResponse + "</span>";
                        }
                    }
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"HomeController HttpPost SaveTestBatchRequest had an enhandled exception.");
                return Json(@"{""error message"": " + e.Message + "}");
            }

            return Json(@"{""null"": null}");
        }
        
        [Route("/liveonbatch/new")]
        public IActionResult LiveOnBatch(int? Id =3)
        {
            try
            {
                if (Id > 0)
                {
                    RunNewTest runNewTest = new RunNewTest();
                    IEnumerable<App> _appList = _appInfoService.GetAppInfoList();
                    runNewTest.Os = _appInfoService.GetOsInfoList();
                    runNewTest.AppInfoList = _appList;
                    TempData["AppId"] = Id;

                    List<App> SelectedApp = _appList.Where(x => x.AppId == Convert.ToInt32(Id)).ToList<App>();
                    ViewBag.SelectedApp = SelectedApp;
                    runNewTest.TargetEnvironments = SelectedApp.Select(x => x.Environments).ToList()[0];
                    TempData["SelctedEnvironments"] = JsonConvert.SerializeObject(runNewTest.TargetEnvironments);
                    TempData["Os"] = JsonConvert.SerializeObject(runNewTest.Os);
                    //TempData["SelectedApp"] = JsonConvert.SerializeObject(SelectedApp);
                    return View(runNewTest);
                }
                else
                {
                    return RedirectToAction("Error");
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"HomeController LiveOnBatch had an enhandled exception.");
                return RedirectToAction("Error");
            }
        }

        public JsonResult jsonFileReturn()
        {
            string contentRootPath = _hostingEnvironment.ContentRootPath;
            var JSON = System.IO.File.ReadAllText(contentRootPath + "/TestType.json");
            return Json(JSON);
        }

        [Route("liveonbatch/{Id}")]
        public async Task<IActionResult> TestBatchResult(string Id)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    Guid testBatchGuid;
                    if (!Guid.TryParse(Id, out testBatchGuid))
                    {
                        _logger.LogError("RequestGuid");
                    }
                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    using (var response = await httpClient.GetAsync(_baseURL + "api/results/batch/" + testBatchGuid))
                    {
                        response.EnsureSuccessStatusCode();
                        Result_TestBatch resp = await response.Content.ReadAsAsync<Result_TestBatch>();
                        
                        string str = JsonConvert.SerializeObject(resp);
                        if (resp.TestBatchId != 0)
                            return View(resp);
                        else
                            return RedirectToAction("Error");
                    }
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"HomeController Batch Results ID Route had an enhandled exception.");
                return RedirectToAction("Error");
            }
        }

        [Route("/liveonbatch")]
        [HttpGet]
        public async Task<IActionResult> BatchSummary(int? pageNum = 1, int? pageSize = 5, bool? by = false, int? appId = 3, int? status = null)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    string APIUrl = "api/results/batch/summary?page=" + pageNum + "&qt=" + pageSize + "";
                    if (by == true)
                    {
                        APIUrl += "&by=" + TempData.Peek("User_FullName");

                        ViewBag.ShowMyResults = "1";
                    }
                    else
                    {
                        ViewBag.ShowMyResults = "";
                    }

                    if (appId != 0)
                    {
                        APIUrl += "&app=" + appId + "";
                    }

                    if (status is not null)
                    {
                        APIUrl += "&status=" + status + "";
                    }


                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    using (var response = await httpClient.GetAsync(_baseURL + APIUrl))
                    {

                        response.EnsureSuccessStatusCode();
                        //int Id = 3; //static appId 
                        List<Batch_Summary> batch_Summary = await response.Content.ReadAsAsync<List<Batch_Summary>>();
                        //foreach (var item in result_Summary)
                        //{

                        //    item.Os = _appInfoService.GetOsInfoList();
                        //    IEnumerable<App> _appList = _appInfoService.GetAppInfoList();
                        //    List<App> SelectedApp = _appList.Where(x => x.AppId == Convert.ToInt32(Id)).ToList<App>();
                        //    item.TargetEnvironments = SelectedApp.Select(x => x.Environments).ToList()[0];
                        //    TempData["Os"] = JsonConvert.SerializeObject(item.Os);
                        //}

                        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                        {
                            return PartialView("_ListBatchSummary", batch_Summary);
                        }

                        else
                        {
                            return View(batch_Summary);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }

        }

        [Route("relaunchtest/{Id}")]
        public IActionResult QuickRelaunchTest(Guid Id)
        {
            return View(Id);

        }
    }
}
