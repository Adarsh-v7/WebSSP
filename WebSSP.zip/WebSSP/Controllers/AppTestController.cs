﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Onlife.Automation.UiTesting.InfoServices.Interfaces;
using Onlife.Automation.UiTesting.Objects.AppObjects;
using Onlife.Automation.UiTesting.Objects.Batch;
using Onlife.Automation.UiTesting.Objects.Info;
using Onlife.Automation.UiTesting.Objects.Requests;
using Onlife.Automation.UiTesting.Objects.Results;
using Onlife.Automation.UiTesting.WebSSP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Onlife.Automation.UiTesting.WebSSP.Controllers
{
    public class AppTestController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IAppInfoService _appInfoService;
        private readonly IGroupInfoService _groupInfoService;
        private readonly IHostingEnvironment _hostingEnvironment;

        public AppTestController(ILogger<HomeController> logger, IAppInfoService appInfoService, IGroupInfoService groupInfoService, IHostingEnvironment hostingEnvironment)
        {
            _logger = logger;
            _appInfoService = appInfoService;
            _groupInfoService = groupInfoService;
            _hostingEnvironment = hostingEnvironment;

        }
        public IActionResult Index()
        {
            return View();
        }

        [Route("Dashboard")]
        //[Route("AppTest/DashBoard")]
        //[Route("DashBoard/{rAppId}")]
        //[Route("DashBoard/{rAppId}/{rEnvId}")]
        public async Task<IActionResult> DashBoard(int rAppId, int rEnvId, bool by = true)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    List<Result_SingleTestSummary> result_Summary = new List<Result_SingleTestSummary>();

                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    ProcessorInfo ProcessorInfo = new ProcessorInfo();
                    List<Batch_Summary> batch_Summary = new List<Batch_Summary>();
                    IEnumerable<App> _appList = _appInfoService.GetAppInfoList();
                    return View(_appList);
                }
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }
        }
        [HttpGet]
        //public async Task<JsonResult> GetProcessorInfo()
        //{
        //    try
        //    {
        //        ProcessorInfo ProcessorInfo = new ProcessorInfo();
        //        string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
        //        using (var httpClient = new HttpClient())
        //        {
        //            string APIUrl = "api/Dashboard/GetProcessorInfo";
        //            using (var response = await httpClient.GetAsync(_baseURL + APIUrl))
        //            {
        //                response.EnsureSuccessStatusCode();
        //                ProcessorInfo = await response.Content.ReadAsAsync<ProcessorInfo>();
        //            }
        //        }
        //        return Json(ProcessorInfo);
        //    }
        //    catch (Exception ex)
        //    { return null; }
        //}
        [HttpGet]
        public async Task<IActionResult> GetTestResult_data(int type, int appId, int envId, bool by, int resultStatusType)
        {
            try
            {
                Thread.Sleep(500);
                using (var httpClient = new HttpClient())
                {
                    string APIUrl = "";
                    if (resultStatusType == 1)// Finished Results
                    {
                        if (type == 1) //Single Result Summary List 
                        {
                            APIUrl = "api/dashboard/Tests/Summary";
                            //  APIUrl += "/" + appId + "/" + envId;
                            APIUrl += "?applicationId=" + appId + "&environmentId=" + envId;
                            if (by == true)
                            {
                                APIUrl += "&user=" + TempData.Peek("User_FullName");
                            }
                        }
                        else if (type == 2) // Batch Result Summary List
                        {
                            APIUrl = "api/dashboard/Batches/Summary";
                            APIUrl += "?applicationId=" + appId + "&environmentId=" + envId;
                        }
                    }
                    else if (resultStatusType == 2)// Queued Results
                    {
                        if (type == 1) //Single Result Summary List 
                        {
                            APIUrl = "api/dashboard/Tests/Queue";
                            APIUrl += "?applicationId=" + appId + "&environmentId" + envId;
                            if (by == true)
                            {
                                APIUrl += "&user=" + TempData.Peek("User_FullName");
                            }
                        }
                        else if (type == 2) // Batch Result Summary List
                        {
                            APIUrl = "api/dashboard/Batches/Queue";
                            APIUrl += "?applicationId=" + appId + "&environmentId" + envId;
                        }
                    }



                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;

                    using (var response = await httpClient.GetAsync(_baseURL + APIUrl))
                    {
                        if (response.StatusCode == System.Net.HttpStatusCode.OK)
                        {
                            if (resultStatusType == 1)// Finished Results
                            {
                                if (type == 1)//Single Result Summary List 
                                {
                                    List<Result_SingleTestSummary> result_Summary = new List<Result_SingleTestSummary>();
                                    result_Summary = await response.Content.ReadAsAsync<List<Result_SingleTestSummary>>();
                                    return PartialView("../shared/AppTest/_SingleTestResultList_Finished", result_Summary);
                                }
                                else if (type == 2)// Batch Result Summary List
                                {
                                    List<Result_BatchSummary> result_Summary = new List<Result_BatchSummary>();
                                    result_Summary = await response.Content.ReadAsAsync<List<Result_BatchSummary>>();
                                    return PartialView("../shared/AppTest/_BatchTestResultList_Finished", result_Summary);
                                }
                            }
                            else if (resultStatusType == 2)// Queued Results
                            {
                                if (type == 1)//Single Result Summary List 
                                {
                                    List<TestRequestQueueInfo> result_Summary = new List<TestRequestQueueInfo>();
                                    result_Summary = await response.Content.ReadAsAsync<List<TestRequestQueueInfo>>();
                                    return PartialView("../shared/AppTest/_SingleTestResultList_Queue", result_Summary);
                                }
                                else if (type == 2)// Batch Result Summary List
                                {
                                    List<BatchQueueInfo> result_Summary = new List<BatchQueueInfo>();
                                    result_Summary = await response.Content.ReadAsAsync<List<BatchQueueInfo>>();
                                    return PartialView("../shared/AppTest/_BatchTestResultList_Queue", result_Summary);
                                }
                            }
                        }
                    }
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("AppTest/ScheduleNewTest/{Id}")]
        public IActionResult ScheduleNewTest(int Id)
        {
            try
            {
                if (Id > 0)
                {
                    RunNewTest runNewTest = new RunNewTest();
                    IEnumerable<App> _appList = _appInfoService.GetAppInfoList();

                    var Os = _appInfoService.GetOsInfoList();
                    if (Id == 2)
                    {
                        runNewTest.Os = Os.Where(x => x.IsMobile == true && x.OsName == "Android").ToList<Objects.OperatingSystem>();
                    }
                    else
                        runNewTest.Os = Os;

                    runNewTest.AppInfoList = _appList;
                    TempData["AppId"] = Id;


                    List<App> SelectedApp = _appList.Where(x => x.AppId == Convert.ToInt32(Id)).ToList<App>();
                    runNewTest.Branches = SelectedApp.Select(x => x.Branches).ToList()[0];
                    ViewBag.SelectedApp = SelectedApp;
                    runNewTest.TargetEnvironments = SelectedApp.Select(x => x.Environments).ToList()[0];
                    TempData["SelctedEnvironments"] = JsonConvert.SerializeObject(runNewTest.TargetEnvironments);
                    TempData["Os"] = JsonConvert.SerializeObject(runNewTest.Os);
                    //TempData["SelectedApp"] = JsonConvert.SerializeObject(SelectedApp);
                    return View(runNewTest);
                }
                else
                {
                    return RedirectToAction("Error");
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"HomeController ScheduleNewTest had an enhandled exception.");
                return RedirectToAction("Error");
            }
        }

        [Route("AppTest/liveonbatch/{Id}")]
        public async Task<IActionResult> BatchResult(string Id)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    Guid testBatchGuid;
                    if (!Guid.TryParse(Id, out testBatchGuid))
                    {
                        _logger.LogError("RequestGuid");
                    }
                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    using (var response = await httpClient.GetAsync(_baseURL + "api/batch/MetaData?batchGuid=" + testBatchGuid))
                    {
                        response.EnsureSuccessStatusCode();
                        BatchMetaData resp = await response.Content.ReadAsAsync<BatchMetaData>();
                        if (resp.TestBatchGuid!=Guid.Empty)
                            return View(resp);
                        else
                            return RedirectToAction("Error");
                    }
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"HomeController Batch Results ID Route had an enhandled exception.");
                return RedirectToAction("Error");
            }
        }

        public async Task<IActionResult> GetBatchResult_data(int type ,Guid batchGuid , int selectedvalue)
        {
            try
            {
               // Thread.Sleep(500);
                using (var httpClient = new HttpClient())
                {
                    string APIUrl = "";

                    if (type == 1) //Result List 
                    {
                        APIUrl = "api/batch/Issues";
                    }
                    else if (type == 2) // App Logs List
                    {
                        APIUrl = "api/batch/AppLog";
                    }
                    else if (type == 3) // UITest Logs List
                    {
                        APIUrl = "api/batch/TestAppLog";
                    }
                    else if (type == 4) // GroupsTested List
                    {
                        APIUrl = "api/batch/GroupsTested";
                    }

                    APIUrl += "?batchGuid=" + batchGuid;

                    string _baseURL = this.Request.Scheme + "://" + this.Request.Host + "/" + this.Request.PathBase;
                    using (var response = await httpClient.GetAsync(_baseURL + APIUrl))
                    {
                        if (response.StatusCode == System.Net.HttpStatusCode.OK)
                        {

                            if (type == 1)//Result List 
                            {
                                List<BatchIssue> resultList = new List<BatchIssue>();
                                resultList = await response.Content.ReadAsAsync<List<BatchIssue>>();
                                if (selectedvalue == 0)
                                {
                                   return PartialView("../shared/AppTest/_batchResultList", resultList);
                                }
                                var result = resultList.Take(selectedvalue);
                                return PartialView("../shared/AppTest/_batchResultList", result);
                            }
                            else if (type == 2)// App Logs List
                            {
                                List<AppLog> appLogsList = new List<AppLog>();
                                appLogsList = await response.Content.ReadAsAsync<List<AppLog>>();
                                if (selectedvalue == 0)
                                {
                                    return PartialView("../shared/AppTest/_batchAppLogsList", appLogsList);
                                }
                                var appLogs = appLogsList.Take(selectedvalue);
                                return PartialView("../shared/AppTest/_batchAppLogsList", appLogs);
                            }
                            else if (type == 3) // UITest Logs List
                            {
                                List<AppLog> uiTestLogsList = new List<AppLog>();
                                uiTestLogsList = await response.Content.ReadAsAsync<List<AppLog>>();
                                if (selectedvalue == 0)
                                {
                                    return PartialView("../shared/AppTest/_batchUITestLogsList", uiTestLogsList);
                                }
                                var uiTestLogs = uiTestLogsList.Take(selectedvalue);
                                return PartialView("../shared/AppTest/_batchUITestLogsList", uiTestLogs);
                            }
                            else if (type == 4) // GroupsTested List
                            {
                                List<BatchGroupList> uiTestLogsList = new List<BatchGroupList>();
                                uiTestLogsList = await response.Content.ReadAsAsync<List<BatchGroupList>>();
                                return PartialView("../shared/AppTest/_batchGroupsTestedList", uiTestLogsList);
                            }
                        }
                    }
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("AppTest/liveonbatch/new")]
        public IActionResult LiveOnBatchRequest(int? Id = 3)
        {
            try
            {
                if (Id > 0)
                {
                    RunNewTest runNewTest = new RunNewTest();
                    IEnumerable<App> _appList = _appInfoService.GetAppInfoList();
                    runNewTest.Os = _appInfoService.GetOsInfoList();
                    runNewTest.AppInfoList = _appList;                                              
                    TempData["AppId"] = Id;
                    List<App> SelectedApp = _appList.Where(x => x.AppId == Convert.ToInt32(Id)).ToList<App>();
                    ViewBag.SelectedApp = SelectedApp;
                    runNewTest.TargetEnvironments = SelectedApp.Select(x => x.Environments).ToList()[0];
                    TempData["SelctedEnvironments"] = JsonConvert.SerializeObject(runNewTest.TargetEnvironments);
                    TempData["Os"] = JsonConvert.SerializeObject(runNewTest.Os);
                    //TempData["SelectedApp"] = JsonConvert.SerializeObject(SelectedApp);
                    return View(runNewTest);
                }
                else
                {
                    return RedirectToAction("Error");
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"HomeController LiveOnBatch had an enhandled exception.");
                return RedirectToAction("Error");
            }
        }
    }
}
