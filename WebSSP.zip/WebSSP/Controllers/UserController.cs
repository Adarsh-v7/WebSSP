﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Onlife.Automation.UiTesting.WebSSP.Models;
using Onlife.Automation.UiTesting.WebSSP.Interfaces;
using Onlife.Automation.UiTesting.WebSSP.Services;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using System.IdentityModel.Tokens.Jwt;

namespace Onlife.Automation.UiTesting.WebSSP.Controllers
{
    public class UserController : Controller
    {
        private IFakeSecurityService _FakeSecurityService;
        private ISecurityService _securityService;
        private readonly ILogger<UserController> _logger;
        public IConfiguration _configuration { get; }

        public UserController(ILogger<UserController> logger,IConfiguration configuration)
        {
            _FakeSecurityService = new FakeSecurityService();
            _securityService = new SecurityService(configuration);
            _logger = logger;
            _configuration = configuration;
        }
        public IActionResult Index()
        {
            return View();
        }


        //[Route("Login")]
        public async Task<ActionResult> Login()
        {
            User _user = new User();
            string token = HttpContext.Session.GetString("JwtToken");

            if (token != null)
            {
                var abcObj = await _securityService.IsValidToken("", "", token);
                if (abcObj)
                    return (RedirectToAction("Dashboard", "AppTest"));
            }
            return View(_user);
        }

        
        [HttpPost("Login")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(User _user)
        {
            if (ModelState.IsValid)
            {
                if (!string.IsNullOrEmpty(Convert.ToString(_user.UserId)) && !string.IsNullOrEmpty(_user.Password))
                {
                    var JwtToken =await _securityService.ValidateUser(_user.UserName, _user.Password);
                    
                    if (JwtToken!="" && JwtToken!=null)
                    {
                        var isValidObj=await _securityService.IsValidToken("","",JwtToken.ToString());
                        if (isValidObj)
                        {
                            var handler = new JwtSecurityTokenHandler();
                            JwtSecurityToken JwtTokenObj = handler.ReadJwtToken(JwtToken);
                            TempData["UserId"] = JwtTokenObj.Payload["nameid"];
                            TempData["User_FullName"] = JwtTokenObj.Payload["unique_name"];
                            HttpContext.Session.SetString("JwtToken", JwtToken.ToString());

                            if (TempData["redirect"] != null)
                            {
                                if (Url.IsLocalUrl(TempData["redirect"].ToString()))
                                {
                                    return Redirect(TempData["redirect"].ToString());
                                }
                                else
                                    return (RedirectToAction("DashBoard", "AppTest"));
                            }
                            else
                                return (RedirectToAction("DashBoard", "AppTest"));
                        }
                    }
                    else
                    {
                        _logger.LogInformation($"User: {_user.UserName} log in failed.");
                        ViewBag.Error = "Login failed";
                    }
                }
                else
                {
                    _logger.LogInformation($"blank username or password");
                    ViewBag.Error = "Please enter valid UserName & Password";
                }
            }
            return View();
        }
        public ActionResult Logout()
        {
            HttpContext.Session.Clear();
            TempData.Clear();
            return RedirectToAction("", "User");
        }
        
        public ActionResult ScheduleNewTest(User _user)
        {

            return View();
        }
    }
}
