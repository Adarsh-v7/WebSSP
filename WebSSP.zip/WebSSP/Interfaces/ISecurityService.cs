﻿using System.IdentityModel.Tokens.Jwt;
using System.Threading.Tasks;

namespace Onlife.Automation.UiTesting.WebSSP.Interfaces
{
    public interface ISecurityService
    {
        Task<string> ValidateUser(string username, string password);
        Task<bool> IsValidToken(string key, string issuer, string token);
    }
}
