﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Onlife.Automation.UiTesting.WebSSP.Models;

namespace Onlife.Automation.UiTesting.WebSSP.Interfaces
{
    public interface IFakeSecurityService
    {
        User LoginCheck(string username, string password);
    }
}
