﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Onlife.Automation.UiTesting.InfoServices.Config
{
    public class SspConfig
    {
        public int PortalTestTimeout { get; set; }
    }
}
