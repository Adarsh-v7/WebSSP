﻿var $faicon;
$(document).on("click", ".relaunch-test", function () {
    var resp = confirm("Are you sure you want to launch this test again?");
    if (resp) {
        var TestRequestGuid = $(this).data("testrequestguid");
        window.open("/RelaunchTest/" + TestRequestGuid, "_blank");
    }
});

function getTestParameters(TestRequestGuid) {
   
    $faicon = $(this).children("i");
    $faicon.addClass("fa-spin");
    var apiurl = "/api/requests/GetTestRequestParameters/" + TestRequestGuid;
    $.get(apiurl, function (data1, status1) {

        var jsonFormData = {
            AppId: data1.app.appId,
            ScheduledDateTime: "2021-05-15T08:00:00.000000-05:00",
            RequestBy: 'Shahid Ali',
            AppTestTypeId: data1.testType.appTestTypeId,
            RunAllTestOptions: data1.runAllTestOptions,
            SelectedOptions: '',//data1.selectedOptions,
            AppEnvironmentId: data1.environment.appEnvironmentId,
            OperatingSystemId: data1.operatingSystem.operatingSystemId,
            DeviceId: data1.operatingSystem.MobileDeviceId,
            BrowserId: data1.browser.browserId,
            ResolutionId: data1.resolution.osResolutionId,
            Parameters: [
                { AppParameterId: 1, Value: data1.testParameters[0].value },
                { AppParameterId: 2, Value: data1.testParameters[1].value }
            ]
        }

        if (status1 == "success") {
            //var strjson = JSON.stringify(jsonFormData);
            SaveTestRequest(jsonFormData);
        }

    });
}

function SaveTestRequest(jsonFormData) {
    $.ajax({
        url: '/api/requests/SaveTestRequest/',
        async: true,
        dataType: 'json',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(jsonFormData),
        success: function (Response_data) {
            console.log(Response_data);
            $("#divLoader #divUpdates").append("<div class='text-success'><i class='fas fa-check mr-2'></i> TestRequest save succeeded</div>");
            $("#divLoader #divUpdates").append("<div>Returned GUID=" + Response_data + "</div>");
            $("#divLoader #divUpdates").append("<div>(POST:api/portaltest) initiated...</div>");
            callTestRunnerAPI(Response_data);
        },
        error: function (jqXhr, textStatus, errorThrown) {
            $("#divLoader #divUpdates").append("<div class='text-danger'><i class='fas fa-times mr-2'></i>Error: textStatus:" + textStatus + ", errorThrown:" + errorThrown + "</div>");
            console.log(errorThrown);
            $("#pleasewaitdiv").hide();
        },
        fail: function (jqXHR, status, err) {
            $("#pleasewaitdiv").hide();
        }
    });
}

function callTestRunnerAPI(guid) {
    var apiurl = '/api/portaltest/' + guid;

    $.ajax({
        url: apiurl,
        async: true,
        dataType: 'json',
        type: 'POST',
        contentType: 'application/json',
        data: guid,
        success: function (response, status) {
            responsedata(response, status)
        },
        error: function (data, textStatus, errorThrown) {
            $("#divLoader #divUpdates").append("<div class='text-danger'><i class='fas fa-times mr-2'></i>Error: textStatus:" + textStatus + "</br> ErrorMessage: " + data.responseText + "</div>");
            console.log(errorThrown);
            $("#pleasewaitdiv").hide();
        },
        fail: function (jqXHR, status, err) {
            $("#pleasewaitdiv").hide();
        }
    });
}

function responsedata(response, status) {
    console.log("status = " + status);
    console.log("DATA POSTED SUCCESSFULLY \n");
    console.log(response);
    console.log(response.recordGuid);
    //if (status == "success") {
    //    if (response.isSuccessful) {
    //        $faicon.removeClass("fa-spin");
    //        window.location.href="/results/" + response.recordGuid;
    //    }
    //    else {
    //    }
    //}
    //else {
        
    //}
    if (status == "success") {
        $("#divLoader #divUpdates").append("<div class='text-success'><i class='fas fa-check mr-2'></i> (POST:api/portaltest) AppTestRunner.Run() has finished.</div>");
        if (response.isSuccessful) {
            $("#divLoader #divUpdates").append("<div class='text-success'>Successful</div>");
            $("#divLoader #divUpdates").append("<div id='showCountDown' class='d-block mt-2'></div>");
            setTimeout(function () { coutdown(response.recordGuid) }, 500);
        }
        else {
            $("#divLoader #divUpdates").append("<div class='text-danger'>" + response.message + "</div>");
            $("#divLoader #divUpdates").append("<div class='text-info'>" + response.recordGuid + "</div>");
            $("#pleasewaitdiv").hide();
        }
    }
    else {
        $("#divLoader #divUpdates").append("<div class='text-danger'>" + status + "</div>");
        $("#divLoader #divUpdates").append("<div class='text-danger'>" + response.message + "</div>");
        $("#divLoader #divUpdates").append("<div class='text-info'>" + response.recordGuid + "</div>");
        $("#pleasewaitdiv").hide();
    }
}

function coutdown(resultid) {
    var n = 3;
    var c = n;
    $('#showCountDown').show();
    $('#showCountDown').text("Reloading page in " + c + " secs.");
    setInterval(function () {
        c--;
        if (c >= 0) {
            $('#showCountDown').text("Reloading page in " + c + " secs.");
        }
        if (c == 0) {
            var URL = "/results/" + resultid;
            window.location = URL;
        }
    }, 1000);
}