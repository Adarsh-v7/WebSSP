﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip();
    $(document).on('click', "#startBtn", function () {
        $(".popup[data-popup='successPopup']").addClass('popupShow');
    })
    $(document).on('click', "#errorBtn", function () {
        $(".popup[data-popup='errorPopup']").addClass('popupShow');
    })
    $(document).on('click', ".hidePopup", function () {
        $(".popup").removeClass('popupShow');
    })
});


function hidebranchusertype() {
    $("#branchType,#userType").hide();
    $("#environment,#testType,#groupSection").show();
}
function configSuit() {
    $("#branchType,#userType,#groupSection").hide();
    $("#environment,#testType").show();
}
function coachon() {
    $("#branchType,#groupSection").hide();
    $("#environment,#testType,#userType").show();
}
function ios() {
    $("#userType").hide();
    $("#groupSection,#branchType,#environment,#testType").show();
}