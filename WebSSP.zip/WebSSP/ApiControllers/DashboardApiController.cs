﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Onlife.Automation.UiTesting.InfoServices.Interfaces;
using Onlife.Automation.UiTesting.Objects.Info;
using Onlife.Automation.UiTesting.Objects.Results;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Onlife.Automation.UiTesting.WebSSP.ApiControllers
{
    [Route("api/dashboard")]
    [ApiController]
    public class DashboardApiController : ControllerBase
    {
        private readonly IAppInfoService _appInfoService;
        private readonly ILogger<DashboardApiController> _logger;

        public DashboardApiController(IAppInfoService appInfoService, ILogger<DashboardApiController> logger)
        {
            _appInfoService = appInfoService;
            _logger = logger;
        }

        [HttpGet("Processor/Info")]
        public async Task<ActionResult<ProcessorInfo>> GetProcessorInfo()
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(GET: ProcessorInfo) initiated.");

            try
            {
                return await _appInfoService.GetProcessorInfo();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(GET: ProcessorInfo) had an unhandled exception.");
                return null;
            }
        }

        [HttpGet("Tests/Queue")]
        public async Task<ActionResult<List<TestRequestQueueInfo>>> GetTestRequestQueueInfo(int applicationId = 0, int environmentId = 0, string user = null, int qty = 25)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(GET: TestQueue) initiated.");

            try
            {
                return await _appInfoService.GetTestRequestQueueInfo(applicationId, environmentId, user, qty);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"(GET: TestQueue) had an unhandled exception.");
                return null;
            }
        }

        [Route("Tests/Summary")]
        [HttpGet]
        public async Task<ActionResult<List<Result_SingleTestSummary>>> GetSingleTestResultSummary(int applicationId = 0, int environmentId = 0, string user = null, int qty = 25) 
        {
            if (!ModelState.IsValid) 
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(GET: TestResults) initiated.");

            try
            {
                return await _appInfoService.GetSingleResultTestSummary(applicationId, environmentId, user, qty);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(GET: TestResults) had an unhandled exception.");
                return null;
            }

        }

        [HttpGet("Batches/Running")]
        public async Task<ActionResult<List<CurrentRunningBatch>>> GetCurrentRunningBatchInfo()
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(GET: CurrentBatch) initiated.");

            try
            {
                return await _appInfoService.GetCurrentRunningBatch();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"(GET: CurrentBatch) had an unhandled exception.");
                return null;
            }
        }

        [HttpGet("Batches/Queue")]
        public async Task<ActionResult<List<BatchQueueInfo>>> GetBatchQueueInfo(int applicationId = 0, int environmentId = 0, string user = null, int qty = 25)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(GET: BatchQueue) initiated.");

            try
            {
                return await _appInfoService.GetBatchQueueInfo(applicationId, environmentId, user, qty);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"(GET: BatchQueue) had an unhandled exception.");
                return null;
            }
        }

        [HttpGet("Batches/Summary")]
        public async Task<ActionResult<List<Result_BatchSummary>>> GetBatchResultSummary(int applicationId = 0, int environmentId = 0, string user = null, int qty = 25)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(GET: BatchResults) initiated.");

            //defaults
            applicationId = applicationId > 0 ? applicationId : 0;
            environmentId = environmentId > 0 ? environmentId : 0;
            user = user?.ToString() ?? null;
            qty = qty > 0 ? qty : 25;

            try
            {
                return await _appInfoService.GetBatchResultSummary(applicationId, environmentId, user, qty);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"(GET: BatchResults) had an unhandled exception.");
                return null;
            }
        }

    }
}