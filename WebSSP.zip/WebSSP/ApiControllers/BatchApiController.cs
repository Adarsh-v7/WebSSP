﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Onlife.Automation.UiTesting.InfoServices.Interfaces;
using Onlife.Automation.UiTesting.Objects.Batch;
using Onlife.Automation.UiTesting.Objects.Info;
using Onlife.Automation.UiTesting.Objects.Requests;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Onlife.Automation.UiTesting.WebSSP.ApiControllers
{
    [Route("api/batch")]
    [ApiController]
    public class BatchApiController : ControllerBase
    {
        private readonly IAppInfoService _appInfoService;
        private readonly ILogger<BatchApiController> _logger;

        public BatchApiController(IAppInfoService appInfoService, ILogger<BatchApiController> logger)
        {
            _appInfoService = appInfoService;
            _logger = logger;
        }

        [HttpGet("MetaData")]
        public async Task<ActionResult<BatchMetaData>> GetBatchMetaData(Guid batchGuid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogTrace("(GET: MetaData) initiated.");

            try
            {
                return await _appInfoService.GetBatchMetaData(batchGuid);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(GET: MetaData) had an unhandled exception.");
                return null;
            }
        }

        [HttpGet("QueueInfo")]
        public async Task<ActionResult<List<BatchProgress>>> GetBatchQueueInfo(Guid batchGuid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogTrace("(GET: QueueInfo) initiated.");

            try
            {
                return await _appInfoService.GetBatchProgress(batchGuid);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(GET: QueueInfo) had an unhandled exception.");
                return null;
            }
        }

        [HttpGet("Issues")]
        public async Task<ActionResult<List<BatchIssue>>> GetBatchIssues(Guid batchGuid)
        {
            if (!ModelState.IsValid || batchGuid == Guid.Empty)
            {
                return BadRequest(ModelState);
            }

            _logger.LogTrace("(GET: Issues) initiated.");

            try
            {
                return await _appInfoService.GetBatchIssues(batchGuid);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(GET: Issues) had an unhandled exception.");
                return null;
            }
        }

        [HttpGet("AppLog")]
        public async Task<ActionResult<List<AppLog>>> GetAppLog(Guid batchGuid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogTrace("(GET: AppLog) initiated.");

            try
            {
                //return await _appInfoService.GetAppLogs(batchGuid);
                return new List<AppLog>();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(GET: AppLog) had an unhandled exception.");
                return null;
            }
        }

        [HttpGet("TestAppLog")]
        public async Task<ActionResult<List<AppLog>>> GetTestAppLog(Guid batchGuid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogTrace("(GET: TestAppLog) initiated.");

            try
            {
                return await _appInfoService.GetTestAppLogs(batchGuid);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(GET: TestAppLog) had an unhandled exception.");
                return null;
            }
        }

        [HttpGet("ErrorCount")]
        public async Task<ActionResult<ErrorCount>> GetErrorCount(Guid batchGuid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogTrace("(GET: ErrorCount) initiated.");

            try
            {
                return await _appInfoService.GetErrorCounts(batchGuid);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(GET: ErrorCount) had an unhandled exception.");
                return null;
            }
        }

        [HttpGet("GroupsTested")]
        public async Task<ActionResult<List<BatchGroupList>>> GetGroupsTested(Guid batchGuid, string testCase = null, bool? isPassing = null)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogTrace("(GET: GroupsTested) initiated.");

            try
            {
                return await _appInfoService.GetBatchGroupList(batchGuid, testCase, isPassing);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(GET: GroupsTested) had an unhandled exception.");
                return null;
            }
        }
    }
}
