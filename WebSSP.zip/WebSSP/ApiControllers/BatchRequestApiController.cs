﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Onlife.Automation.UiTesting.InfoServices.Interfaces;
using Onlife.Automation.UiTesting.Objects.Info;
using Onlife.Automation.UiTesting.Objects.Requests;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Onlife.Automation.UiTesting.WebSSP.ApiControllers
{
    [Route("api/batchrequest")]
    [ApiController]
    public class BatchRequestApiController : ControllerBase
    {
        private readonly IAppInfoService _appInfoService;
        private readonly ILogger<BatchRequestApiController> _logger;

        public BatchRequestApiController(IAppInfoService appInfoService, ILogger<BatchRequestApiController> logger)
        {
            _appInfoService = appInfoService;
            _logger = logger;
        }

        [HttpGet("NamedGroupList")]
        public async Task<ActionResult<List<NamedGroupList>>> GetNamedGroupList(string user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(GET: NamedGroupList) initiated.");

            try
            {
                return await _appInfoService.GetNamedGroupList(user);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(GET: SingleResultTestSummary) had an unhandled exception.");
                return null;
            }
        }

        [Route("BatchProgress")]
        [HttpGet]
        public async Task<ActionResult<List<BatchProgress>>> GetBatchProgress(Guid batchGuid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(GET: BatchProgress) initiated.");

            try
            {
                return await _appInfoService.GetBatchProgress(batchGuid);
            }

            catch (Exception e)
            {
                _logger.LogError(e, "(GET: BatchProgress) had an unhandled exception.");
                return null;
            }
        }
    }
}
