﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Onlife.Automation.UiTesting.Objects.Results;
using Onlife.Automation.UiTesting.Results.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace Onlife.Automation.UiTesting.WebSSP.ApiControllers
{
    [Route("api/results")]
    [Route("api/[controller]")]
    [ApiController]
    public class ResultsApiController : ControllerBase
    {
        private readonly IResultService _resultService;
        private readonly ILogger<ResultsApiController> _logger;

        public ResultsApiController(IResultService resultService, ILogger<ResultsApiController> logger)
        {
            _resultService = resultService;
            _logger = logger;
        }

        [Route("{id}")]
        [HttpGet]
        public async Task<ActionResult<Result_AppTest>> GetResultAsSingle(int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(POST:api/results/{id}) initiated.");

            try
            {
                return await _resultService.GetAppTestResultAsync(id);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(POST:api/results/{{id}}) had an unhandled exception for {id}");
                return null;
            }

        }

        [Route("summary")]
        [HttpGet]
        public async Task<ActionResult<List<Result_Summary>>> GetResultSummary(int qt, int page, int app, string by)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(POST:summary) initiated.");

            try
            {
                return await _resultService.GetResultSummaryAsync(page, qt, app, by);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(POST:summary) had an unhandled exception.");
                return null;
            }
        }

        [Route("batch/{testBatchGuid}")]
        [HttpGet]
        public async Task<ActionResult<Result_TestBatch>> GetTestBatchResult(Guid testBatchGuid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(POST:results/batch/{id}) initiated.");

            try
            {
                return await _resultService.GetTestBatchResultAsync(testBatchGuid);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, "(POST:results/batch/{id}) had an unhandled exception.");
                return null;
            }
        }

        [Route("batch/summary")]
        [HttpGet]
        public async Task<ActionResult<List<Batch_Summary>>> GetBatchSummary(int? qt, int? page, int? app, int? status, string by)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(POST:batchsummary) initiated.");

            try
            {
                return await _resultService.GetBatchSummaryAsync(page, qt, app, status, by);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(POST:batchsummary) had an unhandled exception.");
                return null;
            }
        }
    }
}
