﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Onlife.Automation.UiTesting.Objects;
using Onlife.Automation.UiTesting.Objects.Requests;
using Onlife.Automation.UiTesting.Requests;
using Onlife.Automation.UiTesting.Requests.Interfaces;
using Onlife.Automation.UiTesting.Requests.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Onlife.Automation.UiTesting.WebSSP.ApiControllers
{
    [Route("api/testbatch")]
    [ApiController]
    public class TestBatchApiController : ControllerBase
    {
        private readonly IRequestService _testRequestService;
        private readonly ILogger<TestBatchApiController> _logger;

        public TestBatchApiController(IRequestService testRequestService, ILogger<TestBatchApiController> logger)
        {
            _testRequestService = testRequestService;
            _logger = logger;
        }

        [Route("SaveTestBatchRequest")]
        [HttpPost]
        public async Task<ActionResult<Guid>> SaveTestBatchRequest([FromBody] TestBatchRequestArgs testBatchReqeustArgs)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(POST:api/testbatch) initiated.");

            try
            {

                //record result
                var resp = await _testRequestService.SaveTestBatchRequestAsync(testBatchReqeustArgs);

                if (resp.IsSuccessful)
                {
                    _logger.LogInformation("(POST:api/testbatch) TestBatchRequest save succeeded; returned isSuccessful == true.");
                    return StatusCode(200, resp.RecordGuid);
                }
                else
                {
                    _logger.LogInformation("(POST:api/testbatch) TestBatchRequest save failed; returned isSuccessful == false.");
                    return StatusCode(500, $"Save was unsuccessful. The following message was recorded: {resp.Message}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "(POST:api/testbatch): unhandled exception.");
                return StatusCode(500, "There was an unhandled exception on the server.");
            }
        }

        [HttpPost]
        public async Task<ActionResult<Guid>> SaveTestBatch([FromBody] LiveOnBatchRequest testBatchReqeustArgs)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogTrace("(POST:api/testbatch) initiated.");

            try
            {

                //record result
                var resp = await _testRequestService.SaveTestBatch(testBatchReqeustArgs);

                if (resp.IsSuccessful)
                {
                    _logger.LogInformation("(POST:api/testbatch) TestBatchRequest save succeeded; returned isSuccessful == true.");
                    return StatusCode(200, resp.RecordGuid);
                }
                else
                {
                    _logger.LogInformation("(POST:api/testbatch) TestBatchRequest save failed; returned isSuccessful == false.");
                    return StatusCode(500, $"Save was unsuccessful. The following message was recorded: {resp.Message}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "(POST:api/testbatch): unhandled exception.");
                return StatusCode(500, "There was an unhandled exception on the server.");
            }
        }
    }
}
