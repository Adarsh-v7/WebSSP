﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NLog;
using Onlife.Automation.UiTesting.Objects;
using Onlife.Automation.UiTesting.Objects.Requests;
using Onlife.Automation.UiTesting.Requests;
using Onlife.Automation.UiTesting.Requests.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Onlife.Automation.UiTesting.WebSSP.ApiControllers
{
    [Route("api/requests")]
    [ApiController]
    public class RequestsApiController : ControllerBase
    {
        private readonly IRequestService _requestService;
        private readonly ILogger<RequestsApiController> _logger;

        public RequestsApiController(IRequestService requestService, ILogger<RequestsApiController> logger)
        {
            _requestService = requestService;
            _logger = logger;
        }

        [Route("SaveTestRequest")]
        [HttpPost]
        public async Task<ActionResult<Guid>> SaveTestRequest([FromBody] TestRequestArgs testReqeustArgs)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(POST:api/requests) initiated.");

            try
            {

                //record result
                var resp = await _requestService.SaveTestRequestAsync(testReqeustArgs);

                if (resp.IsSuccessful)
                {
                    MappedDiagnosticsLogicalContext.Set("TestRequestGuid", resp.RecordGuid);

                    _logger.LogInformation("(POST:api/requests) TestRequest save succeeded; returned isSuccessful == true.");
                    return StatusCode(200, resp.RecordGuid);
                }
                else
                {
                    _logger.LogInformation("(POST:api/requests) TestRequest save failed; returned isSuccessful == false.");
                    return StatusCode(500, $"Save was unsuccessful. The following message was recorded: {resp.Message}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "(POST:api/requests): unhandled exception.");
                return StatusCode(500, "There was an unhandled exception on the server.");
            }
        }

        [Route("{testrequestguid}")]
        [HttpGet]
        public async Task<ActionResult<TestResult>> GetRequestAsSingle(Guid testrequestguid)
        {
            MappedDiagnosticsLogicalContext.Set("TestRequestGuid", testrequestguid);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(POST:api/results/{id}) initiated.");

            try
            {
                return await _requestService.GetTestResultAsync(testrequestguid);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(POST:api/requests/{{id}}) had an unhandled exception for {testrequestguid}");
                return null;
            }

        }

        [Route("start/{testrequestguid}")]
        [HttpPost]
        public async Task<ActionResult<TestRequest>> StartTestRequest(Guid testrequestguid)
        {
            MappedDiagnosticsLogicalContext.Set("TestRequestGuid", testrequestguid);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(POST:api/results/start/{testrequestguid}) initiated.");

            try
            {
                return await _requestService.TestRequest_StartAsync(testrequestguid);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(POST:api/results/start/{testrequestguid}) had an unhandled exception for {testrequestguid}");
                return null;
            }

        }

        [Route("GetTestBatchSize")]
        [HttpGet]
        public async Task<ActionResult<List<BatchSize>>> GetTestBatchSize()
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(POST:api/results/{id}) initiated.");

            try
            {
                return await _requestService.GetTestBatchSize();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(POST:api/requests/{{id}}) had an unhandled exception.");
                return null;
            }

        }

        [Route("GetBatchSearchGroup/{_searchKey}")]
        [HttpGet]
        public async Task<ActionResult<List<BatchSize>>> GetBatchSearchGroup(string _searchKey)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _logger.LogInformation("(POST:api/results/{id}) initiated.");

            try
            {
                return await _requestService.GetBatchSearchGroup(_searchKey);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"(POST:api/requests/{{id}}) had an unhandled exception for {_searchKey}");
                return null;
            }

        }

        [Route("GetTestRequestParameters/{TestRequestGuid}")]
        [HttpGet]
        public async Task<TestRequest> GetTestRequestParameters(string TestRequestGuid)
        {
            _logger.LogInformation("(Get:api/results/GetTestRequestParameters) initiated.");

            try
            {
                Guid testBatchGuid;
                if (!Guid.TryParse(TestRequestGuid, out testBatchGuid))
                {
                }
                    return await _requestService.TestRequest_StartAsync(testBatchGuid);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get:api/results/GetTestRequestParameters) had an unhandled exception for {TestRequestGuid}");
                return null;
            }

        }
    }
}
